# Capri-mailonly
The Mail only version of the da capri skin
