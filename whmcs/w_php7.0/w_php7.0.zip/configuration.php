<?php
$license = 'web.ddweb.com.cn';
$db_host = 'localhost';
$db_username = 'ddwebcom_cloud';
$db_password = 'oGE11%c2';
$db_name = 'ddwebcom_cloud';
$cc_encryption_hash = 'sQQQroFjfp7BJWwnKX5zUCAVdmAO8S699KtlMapBgyYvSsPlFCXFs7hT2WK24Jue';
$templates_compiledir = 'templates_c/';
$mysqli_charset = 'utf8';
?>