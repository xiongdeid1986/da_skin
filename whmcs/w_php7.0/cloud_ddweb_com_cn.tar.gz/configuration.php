<?php
$license = 'cloud.ddweb.com.cn';
$db_host = 'localhost';
$db_port = '';
$db_username = 'cloud_whcms';
$db_password = 'oGE11%c2';
$db_name = 'cloud_whcms';
$cc_encryption_hash = 'ugelpoY0LfzPTqVvvN0EGbLuKhkglWGG3KRjZG9ALyfuP0QaEHEbJgvjoGqAtW7n';
$templates_compiledir = 'templates_c';
$mysql_charset = 'utf8';