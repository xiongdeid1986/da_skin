<?php
/**
 * Base Exception class for WHMCS
 *
 * @copyright Copyright (c) WHMCS Limited 2005-2014
 * @license http://www.whmcs.com/license/ WHMCS Eula
 */
class WHMCS_Exception extends Exception
{
}