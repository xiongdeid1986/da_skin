<?php
$license = 'Owned-ac089efd8676b8160e78';
$db_host = 'localhost';
$db_port = '';
$db_username = 'cloud_ddweb';
$db_password = '1QgnIwW2Oyd';
$db_name = 'cloud_ddweb';
$cc_encryption_hash = 'LshS3jVxrvInM0ZTcnsA9gF0cBFMjLpV4xDYGplYKUbmK15NeodevI4yaAbjcr46';
$templates_compiledir = 'templates_c';
$mysql_charset = 'utf8';